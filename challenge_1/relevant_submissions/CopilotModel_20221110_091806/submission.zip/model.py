import os
import tensorflow as tf
class Model:
    def __init__(self, path):
        self.model = tf.keras.models.load_model(os.path.join(path, 'SubmissionModel'))
    def predict(self, X: Any) -> Any:
        """Predict the output for the given input."""
        X = self.preprocess(X)
        return self._model.predict(X)

    def preprocess(self, X: Any) -> Any:
        """Preprocess the input."""
        return X
